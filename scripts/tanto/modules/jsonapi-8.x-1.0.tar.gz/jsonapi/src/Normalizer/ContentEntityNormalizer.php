<?php

namespace Drupal\jsonapi\Normalizer;

/**
 * Converts the Drupal content entity object to a JSON API array structure.
 */
class ContentEntityNormalizer extends EntityNormalizer {}
