<?php

namespace Drupal\jsonapi\Normalizer\Value;

/**
 * @internal
 */
class HttpExceptionNormalizerValue extends FieldNormalizerValue {}
